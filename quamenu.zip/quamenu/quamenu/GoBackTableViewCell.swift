//
//  GoBackTableViewCell.swift
//  quamenu
//
//  Created by logan on 12/17/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

protocol GoBackTableViewDelegate: class{
    func goBackTableViewCell(_ goBackTableViewCell: GoBackTableViewCell)
}

class GoBackTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBAction func GoBackButton(_ sender: AnyObject) {
        delegate?.goBackTableViewCell(self)
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    weak var delegate: GoBackTableViewDelegate?
}
