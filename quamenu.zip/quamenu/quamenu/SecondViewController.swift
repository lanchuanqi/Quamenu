//
//  SecondViewController.swift
//  quamenu
//
//  Created by logan on 11/8/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        WhiteViewWidthConstraint.constant = 196
        redlineHeightConstraint.constant = 0
        targetWidthConstraint.constant = 0
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIView.animate(withDuration: 1.0,animations: { () -> Void in
            self.WhiteViewWidthConstraint.constant = 0
            self.view.layoutIfNeeded()
        }, completion: { (completed) -> Void in
            UIView.animate(withDuration: 1.0, animations: { () -> Void in
                self.redlineHeightConstraint.constant = 206
                self.view.layoutIfNeeded()
            }, completion: { (completed) -> Void in
                UIView.animate(withDuration: 1.0, animations: { () -> Void in
                    self.targetWidthConstraint.constant = 30
                    self.view.layoutIfNeeded()
                })
            }) 
        }) 
    }
    
    @IBOutlet fileprivate var WhiteViewWidthConstraint: NSLayoutConstraint!
    @IBOutlet fileprivate var redlineHeightConstraint: NSLayoutConstraint!
    @IBOutlet fileprivate var targetWidthConstraint: NSLayoutConstraint!
}
