//
//  ConfirmPasswordTableViewCell.swift
//  quamenu
//
//  Created by logan on 12/17/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit


protocol ConfirmPasswordTableViewCellDelegate: class{
    func confirmPasswordTableViewCell(_ confirmPasswordTableViewCell: ConfirmPasswordTableViewCell, Confirm: String)
}

class ConfirmPasswordTableViewCell: UITableViewCell , UITextFieldDelegate{

    @IBOutlet weak var ConfirmPasswordTextField: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        ConfirmPasswordTextField.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        delegate?.confirmPasswordTableViewCell(self, Confirm: self.ConfirmPasswordTextField.text!)
    }
    
    weak var delegate: ConfirmPasswordTableViewCellDelegate?
}
