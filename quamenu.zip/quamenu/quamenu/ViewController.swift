//
//  ViewController.swift
//  quamenu
//
//  Created by logan on 11/8/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UIPageViewControllerDataSource, UIPageViewControllerDelegate{
    var tunaViewController: TunaViewController!
    var secondViewController: SecondViewController!
    var loadingViewController: LoadingViewController!
    var pageViewController: UIPageViewController!
    
    @IBOutlet weak var pageControl: UIPageControl!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tunaViewController = self.storyboard!.instantiateViewController(withIdentifier: "TunaViewController") as! TunaViewController
        self.secondViewController = self.storyboard!.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        self.loadingViewController = self.storyboard!.instantiateViewController(withIdentifier: "LoadingViewController") as! LoadingViewController
        
        self.pageViewController = self.storyboard?.instantiateViewController(withIdentifier: "PageViewController") as! UIPageViewController
        self.pageViewController.dataSource = self
        self.pageViewController.delegate = self
        self.pageViewController.setViewControllers([tunaViewController], direction: .forward, animated: true, completion: nil)

        pageViewController.view.translatesAutoresizingMaskIntoConstraints = false
        pageViewController.view.frame = self.view.bounds

        self.addChildViewController(self.pageViewController)

        
        self.view.insertSubview(self.pageViewController.view, at: 0)
        self.view.addConstraint(self.view.topAnchor.constraint(equalTo: pageViewController.view.topAnchor, constant: 0.0))
        self.view.addConstraint(self.view.bottomAnchor.constraint(equalTo: pageViewController.view.bottomAnchor, constant: 0.0))
        self.view.addConstraint(self.view.leadingAnchor.constraint(equalTo: pageViewController.view.leadingAnchor, constant: 0.0))
        self.view.addConstraint(self.view.trailingAnchor.constraint(equalTo: pageViewController.view.trailingAnchor, constant: 0.0))
        
        self.pageViewController.didMove(toParentViewController: self)
        pageControl.backgroundColor = UIColor.clear
        //Do any additional setup after loading the view, typically from a nib.
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if let currentViewController = pageViewController.viewControllers?.first {
            if currentViewController is TunaViewController {
                pageControl.currentPage = 0
            }
            else if currentViewController is SecondViewController{
                pageControl.currentPage = 1
            }
            else{
                pageControl.currentPage = 2
            }
        }
    }
    // MARK - PageView Controller DataSource
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        var result: UIViewController? = nil
        
        if viewController is SecondViewController {
            result = tunaViewController
        }
        else if viewController is LoadingViewController {
            result = secondViewController
        }
        
        return result
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        var result: UIViewController? = nil
        
        if viewController is TunaViewController {
            result = secondViewController
        }
        else if viewController is SecondViewController {
            result = loadingViewController
        }
        
        return result
    }

    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return 3
    }
    
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        var result = 0
        
        if let viewController = pageViewController.viewControllers?.first {
            if viewController is TunaViewController {
                result = 0
            }
            else if viewController is SecondViewController {
                result = 1
            }
            else if viewController is LoadingViewController {
                result = 2
            }
        }
        
        return result
    }
    
    
    

}

