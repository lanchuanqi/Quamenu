//
//  EmailTableViewCell.swift
//  quamenu
//
//  Created by logan on 12/17/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

protocol EmailTableViewCellDelegate: class{
    func emailTableViewCell(_ emailTableViewCell:EmailTableViewCell, Email: String)
}

class EmailTableViewCell: UITableViewCell, UITextFieldDelegate{

    @IBOutlet weak var EmailTextField: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        EmailTextField.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        delegate?.emailTableViewCell(self, Email: self.EmailTextField.text!)
    }
    
    weak var delegate: EmailTableViewCellDelegate?
}
