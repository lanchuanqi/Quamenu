//
//  UserTableViewCell.swift
//  quamenu
//
//  Created by logan on 12/17/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit


protocol UserTableViewCellDelegate: class{
    func userTableViewCell(_ userTableViewCell: UserTableViewCell, Username: String)
}

class UserTableViewCell: UITableViewCell, UITextFieldDelegate {

    @IBOutlet weak var UsernameTextField: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        UsernameTextField.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        delegate?.userTableViewCell(self, Username: self.UsernameTextField.text!)
    }
    
    weak var delegate: UserTableViewCellDelegate?
}
