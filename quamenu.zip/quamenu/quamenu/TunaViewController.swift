//
//  TunaViewController.swift
//  quamenu
//
//  Created by logan on 11/9/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

class TunaViewController: UIViewController {
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        lineoneImageViewHeightConstraint.constant = 0
        linetwoImageViewHeightConstraint.constant = 0
        clearViewWidthConstraint.constant = 0
        whiteViewWidthConstraint.constant = 201
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        self.view.layoutIfNeeded()
        UIView.animate(withDuration: 1.0,animations: { () -> Void in
            self.clearViewWidthConstraint.constant = 196
            self.whiteViewWidthConstraint.constant = 0
            self.view.layoutIfNeeded()
            }, completion: { (completed) -> Void in
                UIView.animate(withDuration: 1.0, animations: { () -> Void in
                    self.lineoneImageViewHeightConstraint.constant = 194
                    self.view.layoutIfNeeded()
                    }, completion: { (completed) -> Void in
                        UIView.animate(withDuration: 1.0, animations: { () -> Void in
                            self.linetwoImageViewHeightConstraint.constant = 30
                            self.view.layoutIfNeeded()
                        })
                }) 
        }) 
    }
    
    @IBOutlet fileprivate var lineoneImageViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet fileprivate var linetwoImageViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet fileprivate var clearViewWidthConstraint: NSLayoutConstraint!
    @IBOutlet fileprivate var whiteViewWidthConstraint: NSLayoutConstraint!
    
}
