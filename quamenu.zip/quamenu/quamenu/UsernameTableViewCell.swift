//
//  UsernameTableViewCell.swift
//  quamenu
//
//  Created by logan on 12/17/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

protocol UsernameTableViewCellDelegate: class{
    func usernameTableViewCell(_ usernameTableViewCell: UsernameTableViewCell, Username: String)
}

class UsernameTableViewCell: UITableViewCell, UITextFieldDelegate {

    @IBOutlet weak var UsernameTextfield: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        UsernameTextfield.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        delegate?.usernameTableViewCell(self, Username: self.UsernameTextfield.text!)
    }
    
    weak var delegate: UsernameTableViewCellDelegate?
}
