//
//  LogInViewController.swift
//  quamenu
//
//  Created by logan on 11/15/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

class LogInViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, GoBackTableViewDelegate, UsernameTableViewCellDelegate, LogInPasswordTableViewCellDelegate{

    var Username: String?
    var Password: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(LogInViewController.DismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    func DismissKeyboard(){
        view.endEditing(true)
    }
    
    
    // MARK: - Table View Delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "SignupCell") as! GoBackTableViewCell
            cell.delegate = self
            return cell
        }
        else if indexPath.row == 1{
            let cell = tableView.dequeueReusableCell(withIdentifier: "facebookCell") as! LogInFacebookTableViewCell
            return cell
        }
        else if indexPath.row == 2{
            let cell = tableView.dequeueReusableCell(withIdentifier: "Google+Cell") as! LogInGoogleTableViewCell
            return cell
        }
        else if indexPath.row == 3{
            let cell = tableView.dequeueReusableCell(withIdentifier: "usernameCell") as! UsernameTableViewCell
            cell.delegate = self
            return cell
        }
        else if indexPath.row == 4{
            let cell = tableView.dequeueReusableCell(withIdentifier: "passwordCell") as! LogInPasswordTableViewCell
            cell.delegate = self
            return cell
        }
        else{
            let cell = UITableViewCell()
            return cell
        }
    }

    // MARK: - Table View Cell Delegate
    func goBackTableViewCell(_ goBackTableViewCell: GoBackTableViewCell) {
        self.dismiss(animated: true, completion: nil)
    }
    func usernameTableViewCell(_ usernameTableViewCell: UsernameTableViewCell, Username: String) {
        self.Username = Username
    }
    func logInPasswordTableViewCell(_ logInPasswordTableViewCell: LogInPasswordTableViewCell, Password: String) {
        self.Password = Password
    }
    
    
    // MARK: - IBAction
    @IBAction func SignInButton(_ sender: AnyObject) {
        print(self.Username)
        print(self.Password)
    }
    

}
