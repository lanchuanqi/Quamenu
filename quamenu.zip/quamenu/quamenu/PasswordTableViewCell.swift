//
//  PasswordTableViewCell.swift
//  quamenu
//
//  Created by logan on 12/17/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit
protocol PasswordTableViewCellDelegate: class{
    func passwordTableViewCell(_ passwordTableViewCell: PasswordTableViewCell, Password: String)
}


class PasswordTableViewCell: UITableViewCell, UITextFieldDelegate{

    @IBOutlet weak var PasswordTextField: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        PasswordTextField.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        delegate?.passwordTableViewCell(self, Password: self.PasswordTextField.text!)
    }
    
    weak var delegate: PasswordTableViewCellDelegate?
}
