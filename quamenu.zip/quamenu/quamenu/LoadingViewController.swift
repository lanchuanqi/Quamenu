//
//  LoadingViewController.swift
//  quamenu
//
//  Created by logan on 11/8/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

class LoadingViewController: UIViewController {

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        ClearViewHeightConstraint.constant = 0
        topViewheightConstraint.constant = 0
        longLineheightConstraint.constant = 0
        targetwidthConstraint.constant = 0
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIView.animate(withDuration: 1.0,animations: { () -> Void in
            self.ClearViewHeightConstraint.constant = 71
            self.topViewheightConstraint.constant = 35
            self.view.layoutIfNeeded()
        }, completion: { (completed) -> Void in
            UIView.animate(withDuration: 1.0, animations: { () -> Void in
                self.longLineheightConstraint.constant = 221
                self.view.layoutIfNeeded()
                }, completion: { (completed) -> Void in
                    UIView.animate(withDuration: 1.0, animations: { () -> Void in
                        self.targetwidthConstraint.constant = 30
                        self.view.layoutIfNeeded()
                    })
            }) 
        }) 
    }
    
    @IBOutlet fileprivate var ClearViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet fileprivate var topViewheightConstraint: NSLayoutConstraint!
    @IBOutlet fileprivate var longLineheightConstraint: NSLayoutConstraint!
    @IBOutlet fileprivate var targetwidthConstraint: NSLayoutConstraint!
    
}
