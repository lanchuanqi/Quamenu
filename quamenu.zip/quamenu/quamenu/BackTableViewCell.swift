//
//  BackTableViewCell.swift
//  quamenu
//
//  Created by logan on 12/17/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

protocol BackTableViewDelegate: class{
    func backTableViewCell(_ backTableViewCell: BackTableViewCell)
}

class BackTableViewCell: UITableViewCell {
    
    @IBAction func LoginButton(_ sender: AnyObject) {
        delegate?.backTableViewCell(self)
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    weak var delegate: BackTableViewDelegate?
}
