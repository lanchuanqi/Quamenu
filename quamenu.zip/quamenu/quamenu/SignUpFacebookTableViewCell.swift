//
//  SignUpFacebookTableViewCell.swift
//  quamenu
//
//  Created by logan on 12/17/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit


class SignUpFacebookTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
