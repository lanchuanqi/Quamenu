//
//  LogInPasswordTableViewCell.swift
//  quamenu
//
//  Created by logan on 12/17/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit


protocol LogInPasswordTableViewCellDelegate: class{
    func logInPasswordTableViewCell(_ logInPasswordTableViewCell: LogInPasswordTableViewCell, Password: String)
}
class LogInPasswordTableViewCell: UITableViewCell, UITextFieldDelegate {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        PasswordTextField.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBOutlet weak var PasswordTextField: UITextField!
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        delegate?.logInPasswordTableViewCell(self, Password: self.PasswordTextField.text!)
    }
    weak var delegate: LogInPasswordTableViewCellDelegate?
}
