//
//  SignUpViewController.swift
//  quamenu
//
//  Created by logan on 11/15/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, BackTableViewDelegate, UserTableViewCellDelegate, EmailTableViewCellDelegate, PasswordTableViewCellDelegate, ConfirmPasswordTableViewCellDelegate{

    var Username: String?
    var Password: String?
    var Email: String?
    var ConfirmPassword: String?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(SignUpViewController.DismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    func DismissKeyboard(){
        view.endEditing(true)
    }
    
    // MARK: - Table View Delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "BackCell") as! BackTableViewCell
            cell.delegate = self
            return cell
        }
        else if indexPath.row == 1{
            let cell = tableView.dequeueReusableCell(withIdentifier: "facebookCell") as! SignUpFacebookTableViewCell
            return cell
        }
        else if indexPath.row == 2{
            let cell = tableView.dequeueReusableCell(withIdentifier: "google+Cell") as! SignUpGoogleTableViewCell
            return cell
        }
        else if indexPath.row == 3{
            let cell = tableView.dequeueReusableCell(withIdentifier: "nameCell") as! UserTableViewCell
            cell.delegate = self
            return cell
        }
        
        else if indexPath.row == 4{
            let cell = tableView.dequeueReusableCell(withIdentifier: "EmailCell") as! EmailTableViewCell
            cell.delegate = self
            return cell
        }
        else if indexPath.row == 5{
            let cell = tableView.dequeueReusableCell(withIdentifier: "PasswordCell") as! PasswordTableViewCell
            cell.delegate = self
            return cell
        }
        else if indexPath.row == 6{
            let cell = tableView.dequeueReusableCell(withIdentifier: "ConfirmPasswordCell") as! ConfirmPasswordTableViewCell
            cell.delegate = self
            return cell
        }
        
        else{
            let WrongCell = UITableViewCell()
            return WrongCell
        }

    }

    // MARK: - Table View Cell Delegate
    func backTableViewCell(_ backTableViewCell: BackTableViewCell) {
        self.dismiss(animated: true, completion: nil)
    }
    func userTableViewCell(_ userTableViewCell: UserTableViewCell, Username: String) {
        self.Username = Username
    }
    func emailTableViewCell(_ emailTableViewCell: EmailTableViewCell, Email: String) {
        self.Email = Email
    }
    func passwordTableViewCell(_ passwordTableViewCell: PasswordTableViewCell, Password: String) {
        self.Password = Password
    }
    func confirmPasswordTableViewCell(_ confirmPasswordTableViewCell: ConfirmPasswordTableViewCell, Confirm: String) {
        self.ConfirmPassword = Confirm
    }
    
    

    // MARK: - IBAction
    @IBAction func JoinNowButton(_ sender: AnyObject) {
        print(self.Username)
        print(self.Password)
        print(self.Email)
        print(self.ConfirmPassword)
        
    }
    
}
