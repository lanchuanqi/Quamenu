//
//  DistanceViewController.swift
//  quamenu3
//
//  Created by logan on 10/6/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

protocol DistanceViewControllerDelegate: class {
    func distanceViewController(_ distanceViewController: DistanceViewController, didSelectDistance: String)
}

class DistanceViewController: UIViewController {

    @IBOutlet weak var WalkBDButton: UIButton!
    @IBOutlet weak var firstDistance: UIButton!
    @IBOutlet weak var secondDistance: UIButton!
    @IBOutlet weak var thirdDistance: UIButton!
    @IBOutlet weak var fourthDistance: UIButton!
    
    @IBAction func WBDButton(_ sender: AnyObject) {
        if WalkBDButton.titleLabel!.text == "Walking"{
            WalkBDButton.setTitle("Biking", for: UIControlState())
            firstDistance.setTitle("5 blocks", for: UIControlState())
            secondDistance.setTitle("1 mile", for: UIControlState())
            thirdDistance.setTitle("3 miles", for: UIControlState())
            fourthDistance.setTitle("5 miles", for: UIControlState())
        }
        else if WalkBDButton.titleLabel!.text == "Biking"{
            WalkBDButton.setTitle("Driving", for: UIControlState())
            firstDistance.setTitle("1 mile", for: UIControlState())
            secondDistance.setTitle("3 mile", for: UIControlState())
            thirdDistance.setTitle("5 miles", for: UIControlState())
            fourthDistance.setTitle("10 miles", for: UIControlState())
        }
        else if WalkBDButton.titleLabel!.text == "Driving"{
            WalkBDButton.setTitle("Walking", for: UIControlState())
            firstDistance.setTitle("2 blocks", for: UIControlState())
            secondDistance.setTitle("5 blocks", for: UIControlState())
            thirdDistance.setTitle("1 mile", for: UIControlState())
            fourthDistance.setTitle("2 miles", for: UIControlState())
        }
        
    }
    
    @IBAction func didSelect(_ sender: AnyObject) {
        delegate?.distanceViewController(self, didSelectDistance: "  \(firstDistance.titleLabel!.text!)")
    }
    @IBAction func secondDistanceButton(_ sender: AnyObject) {
        delegate?.distanceViewController(self, didSelectDistance: "  \(secondDistance.titleLabel!.text!)")
    }
    @IBAction func thirdDistanceButton(_ sender: AnyObject) {
        delegate?.distanceViewController(self, didSelectDistance: "  \(thirdDistance.titleLabel!.text!)")
    }
    @IBAction func fourthDistanceButton(_ sender: AnyObject) {
        delegate?.distanceViewController(self, didSelectDistance: "  \(fourthDistance.titleLabel!.text!)")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    weak var delegate: DistanceViewControllerDelegate?
}
