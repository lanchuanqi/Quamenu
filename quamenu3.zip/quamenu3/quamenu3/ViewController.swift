//
//  ViewController.swift
//  quamenu3
//
//  Created by logan on 9/30/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

class ViewController: UIViewController, DistanceViewControllerDelegate, QScoreViewControllerDelegate, PriceViewControllerDelegate, HourViewControllerDelegate {
    @IBAction fileprivate func toggleDistance(_ sender: AnyObject) {
        if distanceContainerView.isHidden {
            distanceContainerView.isHidden = false
            distanceContainerView.alpha = 0.0
            UIView.animate(withDuration: 1.0, animations: { () -> Void in
                self.distanceContainerView.alpha = 1.0
            })
        }
        else {
            UIView.animate(withDuration: 1.0, animations: { () -> Void in
                self.distanceContainerView.alpha = 0.0
            }, completion: { (finished) -> Void in
                self.distanceContainerView.isHidden = true
                self.distanceContainerView.alpha = 1.0
            })
        }
    }
    @IBAction func toggleQscore(_ sender: AnyObject) {
        if QscoreContainerView.isHidden {
            QscoreContainerView.isHidden = false
            QscoreContainerView.alpha = 0.0
            UIView.animate(withDuration: 1.0, animations: { () -> Void in
                self.QscoreContainerView.alpha = 1.0
            })
        }
        else {
            UIView.animate(withDuration: 1.0, animations: { () -> Void in
                self.QscoreContainerView.alpha = 0.0
                }, completion: { (finished) -> Void in
                    self.QscoreContainerView.isHidden = true
                    self.QscoreContainerView.alpha = 1.0
            })
        }
    }
    @IBAction func togglePrice(_ sender: AnyObject) {
        if PriceContainerView.isHidden {
            PriceContainerView.isHidden = false
            PriceContainerView.alpha = 0.0
            UIView.animate(withDuration: 1.0, animations: { () -> Void in
                self.PriceContainerView.alpha = 1.0
            })
        }
        else {
            UIView.animate(withDuration: 1.0, animations: { () -> Void in
                self.PriceContainerView.alpha = 0.0
                }, completion: { (finished) -> Void in
                    self.PriceContainerView.isHidden = true
                    self.PriceContainerView.alpha = 1.0
            })
        }
    }
    @IBAction func toggleHours(_ sender: AnyObject) {
        if HourContainerView.isHidden {
            HourContainerView.isHidden = false
            HourContainerView.alpha = 0.0
            UIView.animate(withDuration: 1.0, animations: { () -> Void in
                self.HourContainerView.alpha = 1.0
            })
        }
        else {
            UIView.animate(withDuration: 1.0, animations: { () -> Void in
                self.HourContainerView.alpha = 0.0
                }, completion: { (finished) -> Void in
                    self.HourContainerView.isHidden = true
                    self.HourContainerView.alpha = 1.0
            })
        }
    }
    
    
    func distanceViewController(_ distanceViewController: DistanceViewController, didSelectDistance distance: String) {
        DistanceButton.setTitle("\(distance)", for: UIControlState())
        toggleDistance(self)
    }
    func qscoreViewController(_ qscoreViewController: QScoreViewController, didSelectScore score: String) {
        QScoreButton.setTitle("\(score)", for: UIControlState())
        toggleQscore(self)
    }
    func priceViewController(_ priceViewController: PriceViewController, didSelectPrice price: String) {
        PriceButton.setTitle("\(price)", for: UIControlState())
        togglePrice(self)
    }
    func hourViewController(_ priceViewController: HourViewController, didSelectHour hour: String) {
        HourButton.setTitle("\(hour)", for: UIControlState())
        toggleHours(self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case .some("DistanceEmbedSegue"):
            let distanceViewController = segue.destination as! DistanceViewController
            distanceViewController.delegate = self
        case .some("ScoreEmbedSegue"):
            let qscoreViewController = segue.destination as! QScoreViewController
            qscoreViewController.delegate = self
        case .some("PriceEmbedSegue"):
            let priceViewController = segue.destination as! PriceViewController
            priceViewController.delegate = self
        case .some("HourEmbedSegue"):
            let hourViewController = segue.destination as! HourViewController
            hourViewController.delegate = self
        default:
            super.prepare(for: segue, sender: sender)
        }
    }
    
    
    
    @IBOutlet weak var distanceContainerView: UIView!
    @IBOutlet weak var QscoreContainerView: UIView!
    @IBOutlet weak var PriceContainerView: UIView!
    @IBOutlet weak var HourContainerView: UIView!
    
    @IBOutlet weak var HourButton: UIButton!
    @IBOutlet weak var PriceButton: UIButton!
    @IBOutlet weak var QScoreButton: UIButton!
    @IBOutlet weak var DistanceButton: UIButton!
}

