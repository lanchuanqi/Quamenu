//
//  HourViewController.swift
//  quamenu3
//
//  Created by logan on 10/6/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit

protocol HourViewControllerDelegate: class {
    func hourViewController(_ hourViewController: HourViewController, didSelectHour: String)
}

class HourViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var openTime: UIButton!

    @IBAction func openTimeButton(_ sender: AnyObject) {
        delegate?.hourViewController(self, didSelectHour: "  \(openTime.titleLabel!.text!)")
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    weak var delegate: HourViewControllerDelegate?
}
