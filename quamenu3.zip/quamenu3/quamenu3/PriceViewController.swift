//
//  PriceViewController.swift
//  quamenu3
//
//  Created by logan on 10/6/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit
protocol PriceViewControllerDelegate: class {
    func priceViewController(_ priceViewController: PriceViewController, didSelectPrice: String)
}


class PriceViewController: UIViewController {

    @IBOutlet weak var fourthprice: UIButton!
    @IBOutlet weak var thirdprice: UIButton!
    @IBOutlet weak var secondprice: UIButton!
    @IBOutlet weak var firstprice: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func fourthPriceButton(_ sender: AnyObject) {
        delegate?.priceViewController(self, didSelectPrice: "  \(fourthprice.titleLabel!.text!)")
    }
    
    @IBAction func thirdPriceButton(_ sender: AnyObject) {
        delegate?.priceViewController(self, didSelectPrice: "  \(thirdprice.titleLabel!.text!)")
    }
    @IBAction func firstPriceButton(_ sender: AnyObject) {
        delegate?.priceViewController(self, didSelectPrice: "  \(firstprice.titleLabel!.text!)")
    }
    @IBAction func secondPriceButton(_ sender: AnyObject) {
        delegate?.priceViewController(self, didSelectPrice: "  \(secondprice.titleLabel!.text!)")
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    weak var delegate: PriceViewControllerDelegate?
}
