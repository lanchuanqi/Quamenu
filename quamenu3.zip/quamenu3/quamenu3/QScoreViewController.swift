//
//  QScoreViewController.swift
//  quamenu3
//
//  Created by logan on 10/6/15.
//  Copyright © 2015 logan. All rights reserved.
//

import UIKit
protocol QScoreViewControllerDelegate: class {
    func qscoreViewController(_ qscoreViewController: QScoreViewController, didSelectScore: String)
}

class QScoreViewController: UIViewController {
    
    @IBOutlet weak var WMGIntervel: UIButton!
    @IBOutlet weak var firstScoreButton: UIButton!
    @IBOutlet weak var secondScoreButton: UIButton!
    @IBOutlet weak var thirdScoreButton: UIButton!
    @IBOutlet weak var fourthScoreButton: UIButton!
    
    
    @IBAction func TimeInterval(_ sender: AnyObject) {
        if WMGIntervel.titleLabel!.text == "This Week"{
           WMGIntervel.setTitle("This Month", for: UIControlState())
        }
        else if WMGIntervel.titleLabel!.text == "This Month"{
            WMGIntervel.setTitle("General", for: UIControlState())
            firstScoreButton.setTitle("90+", for: UIControlState())
            secondScoreButton.setTitle("85+", for: UIControlState())
            thirdScoreButton.setTitle("80+", for: UIControlState())
            fourthScoreButton.setTitle("75+", for: UIControlState())
        }
        else if WMGIntervel.titleLabel!.text == "General"{
            WMGIntervel.setTitle("This Week", for: UIControlState())
            firstScoreButton.setTitle("95+", for: UIControlState())
            secondScoreButton.setTitle("90+", for: UIControlState())
            thirdScoreButton.setTitle("85+", for: UIControlState())
            fourthScoreButton.setTitle("80+", for: UIControlState())
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func firstScoreButton(_ sender: AnyObject) {
        delegate?.qscoreViewController(self, didSelectScore: "  \(firstScoreButton.titleLabel!.text!)")
    }
    @IBAction func secondScoreButton(_ sender: AnyObject) {
        delegate?.qscoreViewController(self, didSelectScore: "  \(secondScoreButton.titleLabel!.text!)")
    }
    @IBAction func thirdScoreButton(_ sender: AnyObject) {
        delegate?.qscoreViewController(self, didSelectScore: "  \(thirdScoreButton.titleLabel!.text!)")
    }
    @IBAction func fourthScoreButton(_ sender: AnyObject) {
        delegate?.qscoreViewController(self, didSelectScore: "  \(fourthScoreButton.titleLabel!.text!)")
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    weak var delegate: QScoreViewControllerDelegate?
}
